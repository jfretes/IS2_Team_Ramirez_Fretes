/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g_proy.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ever
 */
@Entity
@Table(name = "User_Stories")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UserStories.findAll", query = "SELECT u FROM UserStories u")
    , @NamedQuery(name = "UserStories.findByCodUs", query = "SELECT u FROM UserStories u WHERE u.codUs = :codUs")
    , @NamedQuery(name = "UserStories.findByDescrCorta", query = "SELECT u FROM UserStories u WHERE u.descrCorta = :descrCorta")
    , @NamedQuery(name = "UserStories.findByDescripcion", query = "SELECT u FROM UserStories u WHERE u.descripcion = :descripcion")
    , @NamedQuery(name = "UserStories.findByEstado", query = "SELECT u FROM UserStories u WHERE u.estado = :estado")
    , @NamedQuery(name = "UserStories.findByTiempoEstimado", query = "SELECT u FROM UserStories u WHERE u.tiempoEstimado = :tiempoEstimado")
    , @NamedQuery(name = "UserStories.findByTiempoReal", query = "SELECT u FROM UserStories u WHERE u.tiempoReal = :tiempoReal")
    , @NamedQuery(name = "UserStories.findByFechaCreacion", query = "SELECT u FROM UserStories u WHERE u.fechaCreacion = :fechaCreacion")
    , @NamedQuery(name = "UserStories.findByPrioridad", query = "SELECT u FROM UserStories u WHERE u.prioridad = :prioridad")})
public class UserStories implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "cod_us")
    private Integer codUs;
    @Size(max = 15)
    @Column(name = "descr_corta")
    private String descrCorta;
    @Size(max = 30)
    @Column(name = "descripcion")
    private String descripcion;
    @Size(max = 10)
    @Column(name = "estado")
    private String estado;
    @Column(name = "tiempo_estimado")
    private Integer tiempoEstimado;
    @Column(name = "tiempo_real")
    private Integer tiempoReal;
    @Column(name = "fecha_creacion")
    @Temporal(TemporalType.DATE)
    private Date fechaCreacion;
    @Size(max = 10)
    @Column(name = "prioridad")
    private String prioridad;
    @JoinColumn(name = "cod_sprint", referencedColumnName = "cod_sprint")
    @ManyToOne
    private Sprint codSprint;
    @JoinColumn(name = "usuario_asignado", referencedColumnName = "cod_usuario")
    @ManyToOne(optional = false)
    private Usuario usuarioAsignado;
    @JoinColumn(name = "usuario_solicitante", referencedColumnName = "cod_usuario")
    @ManyToOne(optional = false)
    private Usuario usuarioSolicitante;

    public UserStories() {
    }

    public UserStories(Integer codUs) {
        this.codUs = codUs;
    }

    public Integer getCodUs() {
        return codUs;
    }

    public void setCodUs(Integer codUs) {
        this.codUs = codUs;
    }

    public String getDescrCorta() {
        return descrCorta;
    }

    public void setDescrCorta(String descrCorta) {
        this.descrCorta = descrCorta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Integer getTiempoEstimado() {
        return tiempoEstimado;
    }

    public void setTiempoEstimado(Integer tiempoEstimado) {
        this.tiempoEstimado = tiempoEstimado;
    }

    public Integer getTiempoReal() {
        return tiempoReal;
    }

    public void setTiempoReal(Integer tiempoReal) {
        this.tiempoReal = tiempoReal;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public Sprint getCodSprint() {
        return codSprint;
    }

    public void setCodSprint(Sprint codSprint) {
        this.codSprint = codSprint;
    }

    public Usuario getUsuarioAsignado() {
        return usuarioAsignado;
    }

    public void setUsuarioAsignado(Usuario usuarioAsignado) {
        this.usuarioAsignado = usuarioAsignado;
    }

    public Usuario getUsuarioSolicitante() {
        return usuarioSolicitante;
    }

    public void setUsuarioSolicitante(Usuario usuarioSolicitante) {
        this.usuarioSolicitante = usuarioSolicitante;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codUs != null ? codUs.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UserStories)) {
            return false;
        }
        UserStories other = (UserStories) object;
        if ((this.codUs == null && other.codUs != null) || (this.codUs != null && !this.codUs.equals(other.codUs))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "g_proy.entities.UserStories[ codUs=" + codUs + " ]";
    }
    
}
