/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author jessi
 */
@Entity
@Table(name = "proyecto")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Proyecto.findAll", query = "SELECT p FROM Proyecto p")
    , @NamedQuery(name = "Proyecto.findByCodProyecto", query = "SELECT p FROM Proyecto p WHERE p.codProyecto = :codProyecto")
    , @NamedQuery(name = "Proyecto.findByNombre", query = "SELECT p FROM Proyecto p WHERE p.nombre = :nombre")
    , @NamedQuery(name = "Proyecto.findByFechaInicio", query = "SELECT p FROM Proyecto p WHERE p.fechaInicio = :fechaInicio")
    , @NamedQuery(name = "Proyecto.findByFechaFinEstimada", query = "SELECT p FROM Proyecto p WHERE p.fechaFinEstimada = :fechaFinEstimada")
    , @NamedQuery(name = "Proyecto.findByEstado", query = "SELECT p FROM Proyecto p WHERE p.estado = :estado")
    , @NamedQuery(name = "Proyecto.findByAnhoProyecto", query = "SELECT p FROM Proyecto p WHERE p.anhoProyecto = :anhoProyecto")})
public class Proyecto implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "cod_proyecto")
    private Long codProyecto;
    @Size(max = 30)
    @Column(name = "nombre")
    private String nombre;
    @Column(name = "fecha_inicio")
    @Temporal(TemporalType.DATE)
    private Date fechaInicio;
    @Column(name = "fecha_fin_estimada")
    @Temporal(TemporalType.DATE)
    private Date fechaFinEstimada;
    @Column(name = "estado")
    private Character estado;
    @Column(name = "anho_proyecto")
    private Integer anhoProyecto;
    @JoinColumn(name = "cod_equipo", referencedColumnName = "cod_equipo")
    @ManyToOne
    private Equipo codEquipo;
    @JoinColumn(name = "cod_sprint", referencedColumnName = "cod_sprint")
    @ManyToOne
    private Sprint codSprint;
    @JoinColumn(name = "usuario_cliente", referencedColumnName = "cod_usuario")
    @ManyToOne(optional = false)
    private Usuario usuarioCliente;

    public Proyecto() {
    }

    public Proyecto(Long codProyecto) {
        this.codProyecto = codProyecto;
    }

    public Long getCodProyecto() {
        return codProyecto;
    }

    public void setCodProyecto(Long codProyecto) {
        this.codProyecto = codProyecto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFinEstimada() {
        return fechaFinEstimada;
    }

    public void setFechaFinEstimada(Date fechaFinEstimada) {
        this.fechaFinEstimada = fechaFinEstimada;
    }

    public Character getEstado() {
        return estado;
    }

    public void setEstado(Character estado) {
        this.estado = estado;
    }

    public Integer getAnhoProyecto() {
        return anhoProyecto;
    }

    public void setAnhoProyecto(Integer anhoProyecto) {
        this.anhoProyecto = anhoProyecto;
    }

    public Equipo getCodEquipo() {
        return codEquipo;
    }

    public void setCodEquipo(Equipo codEquipo) {
        this.codEquipo = codEquipo;
    }

    public Sprint getCodSprint() {
        return codSprint;
    }

    public void setCodSprint(Sprint codSprint) {
        this.codSprint = codSprint;
    }

    public Usuario getUsuarioCliente() {
        return usuarioCliente;
    }

    public void setUsuarioCliente(Usuario usuarioCliente) {
        this.usuarioCliente = usuarioCliente;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codProyecto != null ? codProyecto.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Proyecto)) {
            return false;
        }
        Proyecto other = (Proyecto) object;
        if ((this.codProyecto == null && other.codProyecto != null) || (this.codProyecto != null && !this.codProyecto.equals(other.codProyecto))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.Proyecto[ codProyecto=" + codProyecto + " ]";
    }
    
}
