package com.loginandregister.services;

import com.loginandregister.models.Story;
import com.loginandregister.models.usuarios;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

/**
 * Created by jessi on 17/06/2018.
 */

public interface StoryService {

    @GET("api/modelo.historiausuario")
    Call<List<Story>> listarStories();

    @POST("api/modelo.historiausuario")
    Call<Object> guardarUS(@Body Story story);

    @PUT("api/modelo.historiausuario/{id}")
    Call<Object> actualizarUS(@Path("id") Long id, @Body Story story);

    @DELETE("api/modelo.historiausuario/{id}")
    Call<Object> deleteUS(@Path("id") Long id);
}
