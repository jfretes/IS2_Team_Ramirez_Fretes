package com.loginandregister.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.loginandregister.Home;
import com.loginandregister.R;
import com.loginandregister.adapters.UsuarioSpinnerListAdapter;
import com.loginandregister.models.Story;
import com.loginandregister.models.usuarios;
import com.loginandregister.services.StoryService;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class  ViewHistoriaUsuarioActivity extends AppCompatActivity {

    private Story story;
    private TextView textViewDescripcionCorta, textViewDescripcion, textViewEstimado, textViewAsignado;
    private Button btnFinalizar, btnEliminar, btnEditar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_historia_usuario);
        story = (Story) getIntent().getSerializableExtra("story");
        setToolBar();
        bindUI();

    }

    private void bindUI(){
        //textViewDescripcionCorta, textViewDescripcion, textViewEstimado, textViewAsignado;
        textViewDescripcionCorta = (TextView) findViewById(R.id.textViewDescripcionCorta);
        textViewDescripcionCorta.setText(story.getDescCorta());

        textViewDescripcion = (TextView) findViewById(R.id.textViewDescripcion);
        textViewDescripcion.setText(story.getDescripcion());

        textViewEstimado = (TextView) findViewById(R.id.textViewEstimado);
        textViewEstimado.setText(story.getTiempoEstimado().toString());

        textViewAsignado = (TextView) findViewById(R.id.textViewAsignado);
        textViewAsignado.setText(story.getUsuarioAsignado().getUsername());

        btnFinalizar = (Button) findViewById(R.id.btnFinalizar);
        btnEditar = (Button) findViewById(R.id.btnEditar);
        btnEliminar = (Button) findViewById(R.id.btnEliminar);

        btnFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                story.setEstado("F");
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://192.168.1.4:8080/WEBAPP/") //URL
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
                Long id = story.getCodHu().longValue();
                StoryService servicios = retrofit.create(StoryService.class);
                Call<Object> call = servicios.actualizarUS(id, story);

                call.enqueue(new Callback<Object>() {

                    @Override
                    public void onResponse(Call<Object> call, Response<Object> response) {
                        Toast.makeText(ViewHistoriaUsuarioActivity.this, "User Story actualizado!",
                                Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(ViewHistoriaUsuarioActivity.this, Home.class);
                        startActivity(intent);
                    }

                    @Override
                    public void onFailure(Call<Object> call, Throwable t) {
                        Toast.makeText(ViewHistoriaUsuarioActivity.this, "Ocurrio un error",
                                Toast.LENGTH_LONG).show();
                    }
                });

            }
        });
        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ViewHistoriaUsuarioActivity.this, UserStoryAddActivity.class);
                intent.putExtra("story", story);
                startActivity(intent);
            }
        });
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://192.168.1.4:8080/WEBAPP/") //URL
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
                Long id = story.getCodHu().longValue();
                StoryService servicios = retrofit.create(StoryService.class);
                Call<Object> call = servicios.deleteUS(id);

                call.enqueue(new Callback<Object>() {

                    @Override
                    public void onResponse(Call<Object> call, Response<Object> response) {
                        Toast.makeText(ViewHistoriaUsuarioActivity.this, "User Story Eliminado!",
                                Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(ViewHistoriaUsuarioActivity.this, Home.class);
                        startActivity(intent);
                    }

                    @Override
                    public void onFailure(Call<Object> call, Throwable t) {
                        Toast.makeText(ViewHistoriaUsuarioActivity.this, "Ocurrio un error",
                                Toast.LENGTH_LONG).show();
                    }
                });

            }
        });
    }
    private void setToolBar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("Detalle user story");
    }
}
