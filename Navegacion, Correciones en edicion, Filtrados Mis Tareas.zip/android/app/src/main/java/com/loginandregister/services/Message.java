package com.loginandregister.services;

/**
 * Created by jessi on 11/06/2018.
 */

public class Message {
    private String estado;

    public Message() {
    }

    public Message(String estado) {
        this.estado = estado;

    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
