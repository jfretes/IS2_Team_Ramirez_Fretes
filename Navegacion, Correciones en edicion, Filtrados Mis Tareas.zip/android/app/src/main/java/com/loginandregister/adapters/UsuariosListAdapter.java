package com.loginandregister.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.loginandregister.R;
import com.loginandregister.models.usuarios;

import java.util.List;

/**
 * Created by jessi on 16/06/2018.
 */
//Sirve para customizar,
public class UsuariosListAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private List<usuarios> usuariosList;

    public UsuariosListAdapter(Context context, int layout, List<usuarios> usuariosList) {
        this.context = context;
        this.layout = layout;
        this.usuariosList = usuariosList;
    }

    @Override
    public int getCount() {
        if(usuariosList !=null)
             return usuariosList.size();
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return usuariosList.get(position);

    }

    @Override
    public long getItemId(int position) {
        return usuariosList.get(position).getCodUsuario();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        View v = convertView;
        LayoutInflater layoutInflater = LayoutInflater.from(this.context);
        v = layoutInflater.inflate(R.layout.usuario_list, null);
        usuarios currentTask =(usuarios) getItem(position);
        TextView textView = (TextView) v.findViewById(R.id.username);
        textView.setText(currentTask.getUsername());

        TextView textEstado = (TextView) v.findViewById(R.id.estado);
        textEstado.setText(currentTask.getEstado());
        return v;
    }
}
