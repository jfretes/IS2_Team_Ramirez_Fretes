package com.loginandregister.services;

import com.loginandregister.models.usuarios;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

/**
 * Created by jessi on 16/06/2018.
 */

public interface UsuarioServicios {
    @GET("api/modelo.usuario")
    Call<List<usuarios>> listarUsuarios();

    @POST("api/modelo.usuario")
    Call<Object> guardarUsuario(@Body usuarios user);

    @PUT("api/modelo.usuario/{id}")
    Call<Object> actualizaUsuario(@Path("id") Long id, @Body usuarios user);
}
