package com.loginandregister.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.loginandregister.R;
import com.loginandregister.activities.UserStoryAddActivity;
import com.loginandregister.activities.ViewUserActivity;
import com.loginandregister.activities.addUserActivity;
import com.loginandregister.adapters.UsuariosListAdapter;
import com.loginandregister.models.usuarios;
import com.loginandregister.services.UsuarioServicios;
import com.loginandregister.utils.AppUtils;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * A simple {@link Fragment} subclass.
 */
public class usuarioFragment extends Fragment {

    private ListView listView;
    private Retrofit retrofit;
    private List<usuarios> usuariosList;
    private UsuarioServicios servicios; //UsuariosService
    private FloatingActionButton floatingActionButton;

    public usuarioFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_usuario, container, false); // Inflate the layout for this fragment
        bindUI(v);
        return v;
    }

    private View bindUI(View v){
        floatingActionButton =(FloatingActionButton) v.findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), addUserActivity.class);
                getContext().startActivity(intent);
            }
        });

        listView = (android.widget.ListView) v.findViewById(R.id.listUsuarioView);
        ListarUsuarios(); //getallUser

        return v;
    }

    public void ListarUsuarios(){
        retrofit = new Retrofit.Builder()
                .baseUrl(AppUtils.serverUrl()) //URL
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        servicios = retrofit.create(UsuarioServicios.class);

        Call<List<usuarios>> cUsuario = servicios.listarUsuarios();
        cUsuario.enqueue(new Callback<List<usuarios>>() {
            @Override
            public void onResponse(Call<List<usuarios>> call, Response<List<usuarios>> response) {
                //Aqui se recibe los datos
                usuariosList = response.body();

                UsuariosListAdapter itemAdapter = new UsuariosListAdapter(getContext(),
                        R.layout.usuario_list,usuariosList);
                listView.setAdapter(itemAdapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position,
                                            long id) {
                        Intent intent = new Intent(getContext(), ViewUserActivity.class);
                        intent.putExtra("usuario", (usuarios) listView.getItemAtPosition(position));
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onFailure(Call<List<usuarios>> call, Throwable t) {
                //esto es para los errores
                t.printStackTrace();
                Toast.makeText(getContext(),"Ocurrio un error con los datos!!",
                        Toast.LENGTH_LONG).show();
            }
        });


    }

}
