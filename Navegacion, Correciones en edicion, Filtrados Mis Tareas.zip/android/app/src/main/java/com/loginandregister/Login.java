package com.loginandregister;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loginandregister.services.Message;
import com.loginandregister.services.ServiceLogin;
import com.loginandregister.services.User;
import com.loginandregister.utils.AppUtils;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * Created by jessi on 31/03/2018.
 */

 public class Login extends AppCompatActivity {
        EditText emailBox, passwordBox;
        Button loginButton;
        private SharedPreferences prefs;
        String URL = "http://192.168.1.4:8080/WEBAPP/api/modelo.DemoService/login";

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login);

            prefs = getSharedPreferences("Preferences", Context.MODE_PRIVATE);

            emailBox = (EditText)findViewById(R.id.emailBox);
            passwordBox = (EditText)findViewById(R.id.passwordBox);
            loginButton = (Button)findViewById(R.id.loginButton);


            loginButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Retrofit retrofit = new Retrofit.Builder()
                            .baseUrl(AppUtils.serverUrl() + "api/")
                            .addConverterFactory(GsonConverterFactory.create())
                            .build();

                    ServiceLogin service = retrofit.create(ServiceLogin.class);

                    User user = new User( emailBox.getText().toString(), passwordBox.getText().toString());
                    JSONObject js = new JSONObject();
                    try {
                        js.put("username", emailBox.getText().toString());
                        js.put("password", passwordBox.getText().toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Call<Message> userCall = service.createUser(user);

                    userCall.enqueue(new Callback<Message>() {
                        @Override
                        public void onResponse(Call<Message> call, Response<Message> response) {
                            System.out.println(response.body());
                            Message msg = response.body();
                            if(msg.getEstado().equals("true")){
                                SharedPreferences.Editor editor = prefs.edit();
                                prefs.edit().clear().apply();
                                editor.putString("user", emailBox.getText().toString());
                                editor.commit();
                                editor.apply();

                                Intent intent = new Intent(Login.this, Home.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                Login.this.startActivity(intent);
                                Login.this.finish();
                            }else{
                                Toast.makeText(Login.this, "No autorizado", Toast.LENGTH_LONG).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<Message> call, Throwable t) {
                            Toast.makeText(Login.this, "Error", Toast.LENGTH_LONG).show();
                        }
                    });

                }
            });

        }
    }
