package com.loginandregister.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loginandregister.Home;
import com.loginandregister.R;
import com.loginandregister.models.usuarios;
import com.loginandregister.services.UsuarioServicios;
import com.loginandregister.utils.AppUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class addUserActivity extends AppCompatActivity {
    EditText eUsername, ePassword, ePasswordConfirm;
    Button btnGuardar;
    private Boolean esCrear = true;
    private usuarios instance;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);
        if(getIntent().getSerializableExtra("usuario") != null){
            instance = (usuarios) getIntent().getSerializableExtra("usuario");
            esCrear = false;
        }

        bindUI();


    }

    private void bindUI(){
        eUsername = (EditText) findViewById(R.id.EditTextName);
        ePassword = (EditText) findViewById(R.id.EditPassword);
        ePasswordConfirm = (EditText) findViewById(R.id.EditPasswordConfirm);
        btnGuardar = (Button) findViewById(R.id.ButtonSendFeedback);
        setToolBar();
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if(esCrear){
                if (ePassword.getText().toString().equals(ePasswordConfirm.getText().toString())) {
                    Retrofit retrofit = new Retrofit.Builder()
                            .baseUrl(AppUtils.serverUrl()) //URL
                            .addConverterFactory(GsonConverterFactory.create())
                            .build();
                    UsuarioServicios servicios = retrofit.create(UsuarioServicios.class);

                    usuarios usuario = new usuarios();
                    usuario.setEstado("A");
                    usuario.setUsername(eUsername.getText().toString());
                    usuario.setPassword(ePassword.getText().toString());

                    Call<Object> call = servicios.guardarUsuario(usuario);

                    call.enqueue(new Callback<Object>() {
                        @Override
                        public void onResponse(Call<Object> call, Response<Object> response) {
                            Toast.makeText(addUserActivity.this, "Usuario Guardado",
                                    Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(addUserActivity.this, Home.class);
                            startActivity(intent);//este
                        }
                        @Override
                        public void onFailure(Call<Object> call, Throwable t) {
                            //esto es para los errores
                            t.printStackTrace();
                            Toast.makeText(addUserActivity.this,"Ocurrio un error con los datos!!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    Toast.makeText(addUserActivity.this, "Las contraseñas no coinciden",
                            Toast.LENGTH_LONG).show();
                }
            } else {
                actualizar();
            }

            }
        });

        if(!esCrear){
            eUsername.setText(instance.getUsername().toString());
            ePassword.setVisibility(View.INVISIBLE);
            ePasswordConfirm.setVisibility(View.INVISIBLE);
        }
    }

    private void actualizar(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppUtils.serverUrl()) //URL
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        UsuarioServicios servicios = retrofit.create(UsuarioServicios.class);
        instance.setUsername(eUsername.getText().toString());

        Call<Object> call = servicios.actualizaUsuario(instance.getCodUsuario().longValue(), instance);

        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                Toast.makeText(addUserActivity.this, "Usuario Actualizado con exito",
                        Toast.LENGTH_LONG).show();
                Intent intent = new Intent(addUserActivity.this, Home.class);
                startActivity(intent);//este
            }
            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                //esto es para los errores
                t.printStackTrace();
                Toast.makeText(addUserActivity.this,"Ocurrio un error con los datos!!",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setToolBar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("Usuario");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_action_back);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
