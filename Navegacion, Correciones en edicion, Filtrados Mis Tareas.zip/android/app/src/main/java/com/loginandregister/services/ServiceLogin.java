package com.loginandregister.services;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by jessi on 11/06/2018.
 */

public interface ServiceLogin {

    @POST("modelo.DemoService/login")
    Call<Message> createUser(@Body User user);
}

