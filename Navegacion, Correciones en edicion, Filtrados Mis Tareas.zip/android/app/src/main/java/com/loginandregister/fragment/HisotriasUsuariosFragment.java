package com.loginandregister.fragment;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.loginandregister.R;
import com.loginandregister.activities.UserStoryAddActivity;
import com.loginandregister.activities.ViewHistoriaUsuarioActivity;
import com.loginandregister.adapters.StoryListAdapter;
import com.loginandregister.models.Story;
import com.loginandregister.services.StoryService;
import com.loginandregister.utils.AppUtils;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * A simple {@link Fragment} subclass.
 */
public class HisotriasUsuariosFragment extends Fragment {
    private FloatingActionButton floatingActionButton;
    private ListView listView;
    private Retrofit retrofit;
    private List<Story> storiesList;
    private StoryService servicios; //UsuariosService
    private Boolean misTareas = false;

    public HisotriasUsuariosFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_hisotrias_usuarios, container, false);
        bindUI(v);
        return v;
    }

    private View bindUI(View v){

        floatingActionButton =(FloatingActionButton) v.findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), UserStoryAddActivity.class);
                getContext().startActivity(intent);
            }
        });
        listView = (android.widget.ListView) v.findViewById(R.id.listStoriesView);
        ListarStories(); //getallUser
        return v;
    }

    private void ListarStories(){
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        retrofit = new Retrofit.Builder()
                .baseUrl(AppUtils.serverUrl()) //URL
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        servicios = retrofit.create(StoryService.class);

        Call<List<Story>> call = servicios.listarStories();

        call.enqueue(new Callback<List<Story>>() {
            @Override
            public void onResponse(Call<List<Story>> call, Response<List<Story>> response) {
                storiesList = response.body();
                StoryListAdapter itemAdapter = new StoryListAdapter(getContext(),
                        R.layout.story_item_list,storiesList);
                listView.setAdapter(itemAdapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position,
                                            long id) {
                        Intent intent = new Intent(getContext(), ViewHistoriaUsuarioActivity.class);
                        intent.putExtra("story", (Story) listView.getItemAtPosition(position));
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onFailure(Call<List<Story>> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(getContext(), "Ocurrio un error al intentar obtener datos",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    public void setMisTareas(Boolean v){
        this.misTareas = v;
    }

}
