package com.loginandregister.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.loginandregister.R;
import com.loginandregister.models.Story;

import java.util.List;

/**
 * Created by jessi on 17/06/2018.
 */

public class StoryListAdapter extends BaseAdapter {

    private Context context;
    private int layout;
    private List<Story> storiesList;

    public StoryListAdapter(Context context, int layout, List<Story> storiesList) {
        this.context = context;
        this.layout = layout;
        this.storiesList = storiesList;
    }

    @Override
    public int getCount() {
        if(storiesList!=null) return storiesList.size();
        return 0;
    }

    @Override
    public Object getItem(int i) {
        return storiesList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return storiesList.get(i).getCodHu();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = view;
        LayoutInflater layoutInflater = LayoutInflater.from(this.context);
        v = layoutInflater.inflate(R.layout.story_item_list, null);
        Story currentTask =(Story) getItem(i);
        TextView textView = (TextView) v.findViewById(R.id.name);
        textView.setText(currentTask.getDescCorta() + " · " + currentTask.getUsuarioAsignado().getUsername());

        System.out.println(currentTask.getUsuarioAsignado().getUsername());

        TextView textDescripcion = (TextView) v.findViewById(R.id.descripcion);
        textDescripcion.setText(currentTask.getDescripcion());

        TextView textEstado = (TextView) v.findViewById(R.id.estado);
        textEstado.setText(currentTask.getEstado());
        return v;
    }
}
