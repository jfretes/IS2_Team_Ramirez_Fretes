package com.loginandregister.utils;

/**
 * Created by jessi on 30/06/2018.
 */

public class AppUtils {
    private static String API_BASE_URL = "http://192.168.8.100:8080/WEBAPP/";

    public static String serverUrl(){
        return API_BASE_URL;
    }
}
