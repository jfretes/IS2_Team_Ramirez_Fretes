package com.loginandregister;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.NotificationCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.loginandregister.activities.ViewHistoriaUsuarioActivity;
import com.loginandregister.adapters.StoryListAdapter;
import com.loginandregister.fragment.HisotriasUsuariosFragment;
import com.loginandregister.fragment.MisTareasFragment;
import com.loginandregister.fragment.usuarioFragment;
import com.loginandregister.models.Story;
import com.loginandregister.services.StoryService;
import com.loginandregister.utils.AppUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Home extends AppCompatActivity {
    private NotificationCompat.Builder nbuilder;
    private int NOTIFY_VENCIDAS = 100;
    private SharedPreferences prefs;

    private ImageButton btnSync;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Retrofit retrofit;
    private List<Story> storiesList;
    private StoryService servicios;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        setToolBar();
        bindNavegationView();
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        setFragmentByDefault();


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                // abrir menu lateral
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void setFragmentByDefault(){
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.content_frame, new HisotriasUsuariosFragment())
                .commit();
        getSupportActionBar().setTitle("User Stories");
    }

    private void setToolBar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        View b = findViewById(R.id.tareasavebutton);
        b.setVisibility(View.VISIBLE);
        btnSync = (ImageButton) findViewById(R.id.tareasavebutton);
        btnSync.setBackgroundResource(R.drawable.ic_action_sync);
        btnSync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getNotifications();
            }
        });
    }

    private void bindNavegationView(){
        navigationView = (NavigationView) findViewById(R.id.navview);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                boolean fragmentTransacction = false;
                Fragment fragment = null;

                switch (item.getItemId()){
                    case R.id.menu_mail:
                        fragment = new HisotriasUsuariosFragment();
                        fragmentTransacction = true;
                        break;
                    case R.id.menu_mius:
                        fragment = new MisTareasFragment();
                        fragmentTransacction = true;
                        break;
                    case R.id.menu_config:
                        fragment = new usuarioFragment();
                        fragmentTransacction = true;
                        break;
                }

                if(fragmentTransacction){
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.content_frame, fragment)
                            .commit();
                    item.setChecked(true);
                    getSupportActionBar().setTitle(item.getTitle());
                    drawerLayout.closeDrawers();
                }
                return false;
            }
        });

    }

    public void getNotifications(){
        prefs = getSharedPreferences("Preferences", Context.MODE_PRIVATE);
        final String usuario = prefs.getString("user", "");

        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        retrofit = new Retrofit.Builder()
                .baseUrl(AppUtils.serverUrl()) //URL
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        servicios = retrofit.create(StoryService.class);

        Call<List<Story>> call = servicios.listarStories();

        call.enqueue(new Callback<List<Story>>() {
            @Override
            public void onResponse(Call<List<Story>> call, Response<List<Story>> response) {
                SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd");
                Date today = new Date();
                storiesList = response.body();
                List<Story> filterList =  new ArrayList<>();
                for(Story s :storiesList){
                    if(s.getUsuarioAsignado().getUsername().equals(usuario)){
                        Calendar inicio = new GregorianCalendar();
                        Calendar fin = new GregorianCalendar();
                        fin.setTime(today);
                        try {
                            inicio.setTime(parser.parse(s.getFechaCreacion()));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        int difD = fin.get(Calendar.DAY_OF_YEAR) - inicio.get(Calendar.DAY_OF_YEAR);
                        difD =  s.getTiempoEstimado().intValue()-difD;
                        if(difD <=2){
                            filterList.add(s);
                        }
                    }
                }
                if(filterList.size()>0){
                    configNotification(filterList.size());
                }
            }

            @Override
            public void onFailure(Call<List<Story>> call, Throwable t) {
                t.printStackTrace();
                Toast.makeText(Home.this, "Ocurrio un error al intentar obtener datos",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void configNotification(int i){
        nbuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.ic_stat_nota)
                .setContentTitle("Gestion de Proyectos")
                .setContentText("Existen " + i + " tareas que debes atender");

        /* Intent intent = new Intent(this, AlertDetailsActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        nbuilder.setContentIntent(pendingIntent);*/

        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(NOTIFY_VENCIDAS, nbuilder.build());

    }
}