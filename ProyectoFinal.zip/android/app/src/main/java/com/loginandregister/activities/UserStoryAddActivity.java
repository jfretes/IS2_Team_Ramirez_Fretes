package com.loginandregister.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.loginandregister.Home;
import com.loginandregister.R;
import com.loginandregister.adapters.UsuarioSpinnerListAdapter;
import com.loginandregister.models.Story;
import com.loginandregister.models.usuarios;
import com.loginandregister.services.StoryService;
import com.loginandregister.services.UsuarioServicios;
import com.loginandregister.utils.AppUtils;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class UserStoryAddActivity extends AppCompatActivity {

    private Story story;
    private Boolean esCrear = true;
    private Retrofit retrofit;
    private UsuarioServicios serviceUsuario;
    private StoryService storyService;
    Spinner spinnerUsuarioAsignado, spinnerUsuarioSolicitando;
    private List<usuarios> usuariosList;
    TextView descripcionCorta, descripcion, tiempoEstimado;
    Button btnGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_story_add);
        if(getIntent().getSerializableExtra("story") != null){
            story = (Story) getIntent().getSerializableExtra("story");
            esCrear = false;
        }

        configService();

        bindUI();
        getUserForList();
    }

    private void setUI(){

    }

    private void bindUI(){
        spinnerUsuarioAsignado = (Spinner) findViewById(R.id.SpinnerUsuarioAsignado);
        spinnerUsuarioSolicitando = (Spinner) findViewById(R.id.SpinnerSolicitante);
        descripcionCorta = (TextView) findViewById(R.id.eDescripcionCorta);
        descripcion = (TextView) findViewById(R.id.eDescripcion);
        tiempoEstimado = (TextView) findViewById(R.id.eTiempoEstimado);

        if(!esCrear){
            descripcionCorta.setText(story.getDescCorta().toString());
            descripcion.setText(story.getDescripcion().toString());
            tiempoEstimado.setText(story.getTiempoEstimado().toString());
        }


        setToolBar();

        btnGuardar = (Button) findViewById(R.id.btnGuardarUS);
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Story s = new Story();

                s.setDescCorta(descripcionCorta.getText().toString());
                s.setDescripcion(descripcion.getText().toString());
                s.setEstado("P");
                s.setPrioridad("A");
                s.setTiempoEstimado(Integer.parseInt(tiempoEstimado.getText().toString()));
                s.setTiempoReal(Integer.parseInt(tiempoEstimado.getText().toString()));
                s.setUsuarioSolicitante((usuarios) spinnerUsuarioSolicitando.getSelectedItem());
                s.setUsuarioAsignado((usuarios) spinnerUsuarioAsignado.getSelectedItem());

                if(esCrear){
                    Call<Object> call = storyService.guardarUS(s);

                    call.enqueue(new Callback<Object>() {
                        @Override
                        public void onResponse(Call<Object> call, Response<Object> response) {
                            Toast.makeText(UserStoryAddActivity.this, "User Story Creado",
                                    Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(UserStoryAddActivity.this, Home.class);
                            startActivity(intent);
                        }
                        @Override
                        public void onFailure(Call<Object> call, Throwable t) {
                            //esto es para los errores
                            t.printStackTrace();
                            Toast.makeText(UserStoryAddActivity.this,"Ocurrio un error con los datos!!",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    s.setCodHu(story.getCodHu());
                    Call<Object> call = storyService.actualizarUS(s.getCodHu().longValue(), s);

                    call.enqueue(new Callback<Object>() {

                        @Override
                        public void onResponse(Call<Object> call, Response<Object> response) {
                            Toast.makeText(UserStoryAddActivity.this, "User Story actualizado!",
                                    Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(UserStoryAddActivity.this, Home.class);
                            startActivity(intent);
                        }

                        @Override
                        public void onFailure(Call<Object> call, Throwable t) {
                            Toast.makeText(UserStoryAddActivity.this, "Ocurrio un error",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }

            }
        });
    }

    private void configService(){
        this.retrofit = new Retrofit.Builder()
                .baseUrl(AppUtils.serverUrl())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        this.serviceUsuario = retrofit.create(UsuarioServicios.class);
        this.storyService = retrofit.create(StoryService.class);
    }

    private void getUserForList(){
        Call<List<usuarios>> usuarioCall = serviceUsuario.listarUsuarios();
        usuarioCall.enqueue(new Callback<List<usuarios>>() {
            @Override
            public void onResponse(Call<List<usuarios>> call, Response<List<usuarios>> response) {
                usuariosList = response.body();
                UsuarioSpinnerListAdapter itemAdapter = new UsuarioSpinnerListAdapter(UserStoryAddActivity.this,
                        R.layout.story_item_spinner, usuariosList);
                spinnerUsuarioAsignado.setAdapter(itemAdapter);
                spinnerUsuarioSolicitando.setAdapter(itemAdapter);
                spinnerUsuarioAsignado.setPrompt("Seleccione Usuario Asignado");
                spinnerUsuarioSolicitando.setPrompt("Seleccione Usuario Solicitante");
                if(!esCrear){
                    int posAsignado = 0, posSolicitando = 0;
                    int index = 0;
                    for(usuarios u : usuariosList){
                        if(u.getCodUsuario().equals(story.getUsuarioAsignado().getCodUsuario())){
                            posAsignado = index;
                        }
                        if(u.getCodUsuario().equals(story.getUsuarioSolicitante().getCodUsuario())){
                            posSolicitando = index;
                        }

                        index++;
                    }
                    System.out.println("asigando: " + posAsignado);
                    System.out.println("solicitante:" + posSolicitando);
                    spinnerUsuarioAsignado.setSelection(posAsignado);
                    spinnerUsuarioSolicitando.setSelection(posSolicitando);
                }
            }

            @Override
            public void onFailure(Call<List<usuarios>> call, Throwable t) {
                Toast.makeText(UserStoryAddActivity.this, "Ocurrio un error",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setToolBar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("User Story");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_action_back);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
