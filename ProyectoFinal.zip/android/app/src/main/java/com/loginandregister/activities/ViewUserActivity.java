package com.loginandregister.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.loginandregister.R;
import com.loginandregister.models.usuarios;

public class ViewUserActivity extends AppCompatActivity {
    private usuarios instance;
    private Button btnEditar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_user);
        instance = (usuarios) getIntent().getSerializableExtra("usuario");

        bindUI();
        setToolBar();
    }

    private void bindUI(){
        TextView textCod = (TextView) findViewById(R.id.usuarioCod);
        TextView textUsername = (TextView) findViewById(R.id.nombreUsuario);
        TextView textEstado = (TextView) findViewById(R.id.estado);

        textCod.setText(": " + instance.getCodUsuario().toString());
        textUsername.setText(": " + instance.getUsername().toString());
        textEstado.setText(instance.getEstado().equals("A")?": Activo":": Inactivo");

        btnEditar = (Button) findViewById(R.id.buttonEditar);
        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ViewUserActivity.this, addUserActivity.class);
                intent.putExtra("usuario", instance);
                startActivity(intent);
            }
        });

    }

    private void setToolBar(){
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("Usuario");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_action_back);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
