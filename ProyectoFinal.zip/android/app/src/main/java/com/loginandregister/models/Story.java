package com.loginandregister.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Story implements Serializable {

    @SerializedName("codHu")
    @Expose
    private Integer codHu;
    @SerializedName("descCorta")
    @Expose
    private String descCorta;
    @SerializedName("descripcion")
    @Expose
    private String descripcion;
    @SerializedName("estado")
    @Expose
    private String estado;
    @SerializedName("fechaCreacion")
    @Expose
    private String fechaCreacion;
    @SerializedName("prioridad")
    @Expose
    private String prioridad;
    @SerializedName("tiempoEstimado")
    @Expose
    private Integer tiempoEstimado;
    @SerializedName("tiempoReal")
    @Expose
    private Integer tiempoReal;
    @SerializedName("usuarioAsignado")
    @Expose
    private usuarios usuarioAsignado;
    @SerializedName("usuarioSolicitante")
    @Expose
    private usuarios usuarioSolicitante;

    public Integer getCodHu() {
        return codHu;
    }

    public void setCodHu(Integer codHu) {
        this.codHu = codHu;
    }

    public String getDescCorta() {
        return descCorta;
    }

    public void setDescCorta(String descCorta) {
        this.descCorta = descCorta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public Integer getTiempoEstimado() {
        return tiempoEstimado;
    }

    public void setTiempoEstimado(Integer tiempoEstimado) {
        this.tiempoEstimado = tiempoEstimado;
    }

    public Integer getTiempoReal() {
        return tiempoReal;
    }

    public void setTiempoReal(Integer tiempoReal) {
        this.tiempoReal = tiempoReal;
    }

    public usuarios getUsuarioAsignado() {
        return usuarioAsignado;
    }

    public void setUsuarioAsignado(usuarios usuarioAsignado) {
        this.usuarioAsignado = usuarioAsignado;
    }

    public usuarios getUsuarioSolicitante() {
        return usuarioSolicitante;
    }

    public void setUsuarioSolicitante(usuarios usuarioSolicitante) {
        this.usuarioSolicitante = usuarioSolicitante;
    }

}