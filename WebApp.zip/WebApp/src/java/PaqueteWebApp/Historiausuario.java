/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PaqueteWebApp;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Ever
 */
@Entity
@Table(name = "Historia_usuario")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Historiausuario.findAll", query = "SELECT h FROM Historiausuario h")
    , @NamedQuery(name = "Historiausuario.findByCodHu", query = "SELECT h FROM Historiausuario h WHERE h.codHu = :codHu")
    , @NamedQuery(name = "Historiausuario.findByDescCorta", query = "SELECT h FROM Historiausuario h WHERE h.descCorta = :descCorta")
    , @NamedQuery(name = "Historiausuario.findByDescripcion", query = "SELECT h FROM Historiausuario h WHERE h.descripcion = :descripcion")
    , @NamedQuery(name = "Historiausuario.findByEstado", query = "SELECT h FROM Historiausuario h WHERE h.estado = :estado")
    , @NamedQuery(name = "Historiausuario.findByTiempoEstimado", query = "SELECT h FROM Historiausuario h WHERE h.tiempoEstimado = :tiempoEstimado")
    , @NamedQuery(name = "Historiausuario.findByTiempoReal", query = "SELECT h FROM Historiausuario h WHERE h.tiempoReal = :tiempoReal")
    , @NamedQuery(name = "Historiausuario.findByFechaCreacion", query = "SELECT h FROM Historiausuario h WHERE h.fechaCreacion = :fechaCreacion")
    , @NamedQuery(name = "Historiausuario.findByPrioridad", query = "SELECT h FROM Historiausuario h WHERE h.prioridad = :prioridad")})
public class Historiausuario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "cod_hu")
    private Long codHu;
    @Size(max = 30)
    @Column(name = "desc_corta")
    private String descCorta;
    @Size(max = 100)
    @Column(name = "descripcion")
    private String descripcion;
    @Column(name = "estado")
    private Character estado;
    @Column(name = "tiempo_estimado")
    private Integer tiempoEstimado;
    @Column(name = "tiempo_real")
    private Integer tiempoReal;
    @Column(name = "fecha_creacion")
    @Temporal(TemporalType.DATE)
    private Date fechaCreacion;
    @Column(name = "prioridad")
    private Character prioridad;
    @JoinTable(name = "Sprint_HU", joinColumns = {
        @JoinColumn(name = "cod_hu", referencedColumnName = "cod_hu")}, inverseJoinColumns = {
        @JoinColumn(name = "cod_sprint", referencedColumnName = "cod_sprint")})
    @ManyToMany
    private Collection<Sprint> sprintCollection;
    @JoinColumn(name = "usuario_asignado", referencedColumnName = "cod_usuario")
    @ManyToOne
    private Usuario usuarioAsignado;
    @JoinColumn(name = "usuario_solicitante", referencedColumnName = "cod_usuario")
    @ManyToOne
    private Usuario usuarioSolicitante;

    public Historiausuario() {
    }

    public Historiausuario(Long codHu) {
        this.codHu = codHu;
    }

    public Long getCodHu() {
        return codHu;
    }

    public void setCodHu(Long codHu) {
        this.codHu = codHu;
    }

    public String getDescCorta() {
        return descCorta;
    }

    public void setDescCorta(String descCorta) {
        this.descCorta = descCorta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Character getEstado() {
        return estado;
    }

    public void setEstado(Character estado) {
        this.estado = estado;
    }

    public Integer getTiempoEstimado() {
        return tiempoEstimado;
    }

    public void setTiempoEstimado(Integer tiempoEstimado) {
        this.tiempoEstimado = tiempoEstimado;
    }

    public Integer getTiempoReal() {
        return tiempoReal;
    }

    public void setTiempoReal(Integer tiempoReal) {
        this.tiempoReal = tiempoReal;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Character getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(Character prioridad) {
        this.prioridad = prioridad;
    }

    @XmlTransient
    public Collection<Sprint> getSprintCollection() {
        return sprintCollection;
    }

    public void setSprintCollection(Collection<Sprint> sprintCollection) {
        this.sprintCollection = sprintCollection;
    }

    public Usuario getUsuarioAsignado() {
        return usuarioAsignado;
    }

    public void setUsuarioAsignado(Usuario usuarioAsignado) {
        this.usuarioAsignado = usuarioAsignado;
    }

    public Usuario getUsuarioSolicitante() {
        return usuarioSolicitante;
    }

    public void setUsuarioSolicitante(Usuario usuarioSolicitante) {
        this.usuarioSolicitante = usuarioSolicitante;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codHu != null ? codHu.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Historiausuario)) {
            return false;
        }
        Historiausuario other = (Historiausuario) object;
        if ((this.codHu == null && other.codHu != null) || (this.codHu != null && !this.codHu.equals(other.codHu))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "PaqueteWebApp.Historiausuario[ codHu=" + codHu + " ]";
    }
    
}
