/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PaqueteWebApp.service;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 *
 * @author Ever
 */
@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(PaqueteWebApp.service.EquipoFacadeREST.class);
        resources.add(PaqueteWebApp.service.HistoriausuarioFacadeREST.class);
        resources.add(PaqueteWebApp.service.PermisoFacadeREST.class);
        resources.add(PaqueteWebApp.service.PersonaFacadeREST.class);
        resources.add(PaqueteWebApp.service.ProyectoFacadeREST.class);
        resources.add(PaqueteWebApp.service.RolFacadeREST.class);
        resources.add(PaqueteWebApp.service.SprintFacadeREST.class);
        resources.add(PaqueteWebApp.service.UsuarioFacadeREST.class);
    }
    
}
